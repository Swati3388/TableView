//
//  TableView_AssignmentApp.swift
//  TableView_Assignment
//
//  Created by Swati Dasgupta on 02/05/24.
//

import SwiftUI

@main
struct TableView_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
