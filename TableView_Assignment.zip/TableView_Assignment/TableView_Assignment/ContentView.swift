//
//  ContentView.swift
//  TableView_Assignment
//
//  Created by Swati Dasgupta on 02/05/24.
//

import SwiftUI

//Specify Data Model
struct Post: Codable, Identifiable {
    let id: Int
    let title: String
    // Add other properties as needed
}

//Specify Data Fetching From API 
class DataFetcher: ObservableObject {
    @Published var posts: [Post] = []
    private var currentPage = 1
    private let pageSize = 5
    
    func fetchData() {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts?_page=\(currentPage)&_limit=\(pageSize)") else {
            return
        }
        URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            guard let data = data else { return }
            do {
                let decoder = JSONDecoder()
                let fetchedPosts = try decoder.decode([Post].self, from: data)
                DispatchQueue.main.async {
                    self?.posts.append(contentsOf: fetchedPosts)
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }.resume()
    }
}

struct ContentView: View {
    @ObservedObject var dataFetcher = DataFetcher()
    
    var body: some View {
        NavigationView {
            List(dataFetcher.posts) { post in
                Text("\(post.id) - \(post.title)")
            }
            .onAppear(perform: {
                self.dataFetcher.fetchData()
            })
            .navigationBarTitle("Posts")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#Preview {
    ContentView()
}
